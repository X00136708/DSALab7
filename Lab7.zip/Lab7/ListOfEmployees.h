#pragma once
#include <iostream>
#include <cmath>
using namespace std;
class Employee {
private:
	string name;
	double salary;
public:
	Employee();
	Employee(string n, double s);
	friend ostream& operator<<(ostream& output, const Employee& e);
	Employee(const Employee& e);
	Employee& operator=(const Employee& e);
	~Employee();
	 
};