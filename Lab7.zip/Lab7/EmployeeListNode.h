#pragma once
#include <iostream>
using namespace std;
class EmployeesListNode {
public:
	EmployeesListNode();
	EmployeesListNode(string, double);
	void insertAtFront(string s, double n);
	void deleteMostRecent();
	void getSalary(string name);

private:
	typedef struct list {
		int data;
		list* next;
	}*nodePointer;
	nodePointer head;
	nodePointer current;
	nodePointer temp;
};