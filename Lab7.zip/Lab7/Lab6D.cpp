#include <iostream>
#include <cmath>
#include <string>
#include "ListOfEmployees.h"
#include "EmployeeListNode.h"
using namespace std;


Employee::Employee(string n, double s) {
	name = n;
	salary = s;
}
 ostream& operator<<(ostream& output, const Employee& e) {
	 output << "Employee name: " << e.name << endl << "Employee salary: " << e.salary << " " << endl;
	 return output;
}
 Employee::Employee(const Employee& e) {
	 cout << "Copy constructor called " << endl;
	 name = e.name;
	 salary = e.salary;
 }
 Employee::Employee& operator=(const Employee& e) {

 }
                                                                                                             